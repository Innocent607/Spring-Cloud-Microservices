package bw.co.fnbbotswana.ws.branchservice.exception;

public class BranchException extends BaseException {

    public BranchException(int code, String message) {
        super(code, message);
    }

    public BranchException(int code, String message, Throwable cause) {
        super(code, message, cause);
    }

    public BranchException(String message) {
        super(message);
    }

    public BranchException(String message, Throwable cause) {
        super(message, cause);
    }
}

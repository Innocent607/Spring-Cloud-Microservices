package bw.co.fnbbotswana.ws.branchservice.service;

import bw.co.fnbbotswana.ws.branchservice.rest.Branch;
import bw.co.fnbbotswana.ws.branchservice.rest.BranchResponse;
import reactor.core.publisher.Mono;

import java.io.IOException;
import java.util.List;

public interface BranchInquiryService {

    List<Branch> findAll() throws IOException;

}

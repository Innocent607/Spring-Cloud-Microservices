package bw.co.fnbbotswana.ws.branchservice.rest.bootstrap;

import bw.co.fnbbotswana.ws.branchservice.rest.Branch;
import com.fasterxml.jackson.core.JacksonException;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.JsonDeserializer;
import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import lombok.NoArgsConstructor;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

@NoArgsConstructor
public class BranchDeserializer2 extends JsonDeserializer<Branch> {
    private String animalTypeElementName;
    private Gson gson;
    private Map<String, Class<? extends Branch>> animalTypeRegistry;

    public BranchDeserializer2(String animalTypeElementName) {
        this.animalTypeElementName = animalTypeElementName;
        this.gson = new Gson();
        this.animalTypeRegistry = new HashMap<>();
    }

    public void registerBarnType(String animalTypeName, Class<? extends Branch> animalType) {
        animalTypeRegistry.put(animalTypeName, animalType);
    }

    @Override
    public Branch deserialize(JsonParser p, DeserializationContext ctxt) throws IOException, JacksonException {
        JsonObject animalObject = p.getCodec().readTree(p);
        JsonElement animalTypeElement = animalObject.get(animalTypeElementName);

        Class<? extends Branch> animalType = animalTypeRegistry.get(animalTypeElement.getAsString());

        return gson.fromJson(animalObject, animalType);
    }
}

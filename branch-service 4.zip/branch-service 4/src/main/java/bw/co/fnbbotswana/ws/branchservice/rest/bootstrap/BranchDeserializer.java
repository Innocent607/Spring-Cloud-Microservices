package bw.co.fnbbotswana.ws.branchservice.rest.bootstrap;

import bw.co.fnbbotswana.ws.branchservice.rest.Branch;
import com.fasterxml.jackson.core.JacksonException;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.deser.std.StdDeserializer;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class BranchDeserializer extends StdDeserializer {

    String name, code, fax, tel, postal, location;

    public BranchDeserializer () {
        this(null);
    }

    public BranchDeserializer (Class<?> vc) {
        super(vc);
    }

    @Override
    public Branch deserialize(JsonParser jsonParser, DeserializationContext ctxt)
            throws IOException, JacksonException, JsonProcessingException {

        Branch branch = new Branch();
        JsonNode branchNode = jsonParser.getCodec().readTree(jsonParser);

        branch.setBranchName(branchNode.get("BranchName").textValue());
        branch.setBranchCode(branchNode.get("BranchCode").textValue());
        branch.setFaxNumber(branchNode.get("Fax").textValue());
        branch.setTelephone(branchNode.get("Telephone").textValue());
        branch.setPostalAddress(branchNode.get("PostalAddress").textValue());
        branch.setLocation(branchNode.get("Location").textValue());

        //new - to list
//        ObjectMapper mapper = new ObjectMapper();
//        List<Branch> branches = new ArrayList<Branch>();
//
//        for (int i=0; i< branchNode.size(); i++) {
//
//            name = branchNode.get("Branches").get(i).get("BranchName").textValue();
//            code = branchNode.get("Branches").get(i).get("BranchCode").textValue();
//            fax = branchNode.get("Branches").get(i).get("BranchName").textValue();
//            tel = branchNode.get("Branches").get(i).get("BranchCode").textValue();
//            postal = branchNode.get("Branches").get(i).get("BranchName").textValue();
//            location = branchNode.get("Branches").get(i).get("BranchCode").textValue();
//
//            branches.add(new Branch(name, code, fax, tel, postal, location));
//        };
        return branch;
    }
}

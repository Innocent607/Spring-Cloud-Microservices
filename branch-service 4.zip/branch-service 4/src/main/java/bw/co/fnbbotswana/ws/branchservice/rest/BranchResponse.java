package bw.co.fnbbotswana.ws.branchservice.rest;

/*
Author: O. Maswabi
AKA Inno607
System Analyst @ FNBB
*/

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import java.util.List;

@Getter
@Setter
@ToString
@RequiredArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class BranchResponse {

    public List<Branch> branch;

}

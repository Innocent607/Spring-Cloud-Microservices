package bw.co.fnbbotswana.ws.branchservice.service.Impl;

import bw.co.fnbbotswana.ws.branchservice.rest.Branch;
import bw.co.fnbbotswana.ws.branchservice.rest.BranchResponse;
import bw.co.fnbbotswana.ws.branchservice.service.BranchInquiryService;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;


import java.io.File;
import java.io.IOException;
import java.util.List;

@AllArgsConstructor
@Service
public class BranchInquiryServiceImpl implements BranchInquiryService {
    @Override
    public List<Branch> findAll() throws IOException {

        ObjectMapper mapper = new ObjectMapper();
        //Branch branch = mapper.readValue(new File("src/main/resources/fnb-branches.json"), Branch.class);

        JsonNode jsonNode = mapper.readValue(new File("src/main/resources/fnb-branches.json"), JsonNode.class);
        String jsonArray = mapper.writeValueAsString(jsonNode);
        List<Branch> branches = mapper.readValue(jsonArray, new TypeReference<List<Branch>>() {});

        return  branches;
    }

}

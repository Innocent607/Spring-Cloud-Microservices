package bw.co.fnbbotswana.ws.branchservice.controller.support;

import bw.co.fnbbotswana.ws.branchservice.controller.model.ErrorResponse;
import bw.co.fnbbotswana.ws.branchservice.exception.BaseException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.annotation.Order;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

@Slf4j
@RestController
@ControllerAdvice(annotations = {RestController.class})
public class ExceptionHandlerAdvice {

    @ExceptionHandler({BaseException.class})
    @ResponseStatus(value = HttpStatus.INTERNAL_SERVER_ERROR)
    public ResponseEntity<ErrorResponse> error(BaseException ex) {
        return  new ResponseEntity<>(convertBaseError(ex), HttpStatus.INTERNAL_SERVER_ERROR);
    }

    @Order
    @ExceptionHandler(Throwable.class)
    @ResponseStatus(value = HttpStatus.INTERNAL_SERVER_ERROR)
    public ResponseEntity<ErrorResponse> genericError(Exception ex) {
        return new ResponseEntity<>(convertGenericError(ex), HttpStatus.INTERNAL_SERVER_ERROR);
    }

    private ErrorResponse convertGenericError(Exception ex) {

        String errorMessage = ex.getMessage() != null ? ex.getMessage() : ex.toString();
        ErrorResponse errorResponse = new ErrorResponse(99999, errorMessage);
        log.error(errorResponse.toString(), ex);
        return errorResponse;
    }

    private ErrorResponse convertBaseError(BaseException ex) {

        ErrorResponse errorResponse = new ErrorResponse(ex.getCode(), ex.getMessage());
        log.error(errorResponse.toString(), ex);
        return errorResponse;
    }
}

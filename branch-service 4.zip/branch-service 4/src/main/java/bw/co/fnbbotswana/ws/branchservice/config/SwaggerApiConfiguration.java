//package bw.co.fnbbotswana.ws.branchservice.config;
//
//import io.swagger.v3.oas.models.OpenAPI;
//import io.swagger.v3.oas.models.info.Contact;
//import io.swagger.v3.oas.models.info.Info;
//import io.swagger.v3.oas.models.info.License;
//import io.swagger.v3.oas.models.servers.Server;
//import org.springdoc.core.GroupedOpenApi;
//import org.springframework.beans.factory.annotation.Value;
//import org.springframework.context.annotation.Bean;
//import org.springframework.context.annotation.Configuration;
//
//@Configuration
//public class SwaggerApiConfiguration {
//
//    private static final String ALL_API_PATH = "/api/**";
//    private static final String COMPANY_INQUIRY_V1_PATH = "/api/v1/**";
//    private static final String ACTUATOR_PATH = "/actuator/**";
//
//    @Value("${server.servlet.context-path}")
//    String contextPath;
//
//    @Value("${info.build.version}")
//    String version;
//
//    @Bean
//    GroupedOpenApi apiAll() {
//
//        return GroupedOpenApi.builder()
//                .group("All")
//                .pathsToMatch(ALL_API_PATH)
//                .build();
//    }
//
//    @Bean
//    GroupedOpenApi lookUp() {
//
//        return GroupedOpenApi.builder()
//                .group("Branch Service Version 1")
//                .pathsToMatch(COMPANY_INQUIRY_V1_PATH)
//                .build();
//    }
//
//    @Bean
//    GroupedOpenApi systemHealthApi() {
//
//        return GroupedOpenApi.builder()
//                .group("System Health")
//                .pathsToMatch(ACTUATOR_PATH)
//                .build();
//    }
//
//    @Bean
//    OpenAPI generalOpenApi() {
//        return new OpenAPI()
//                .addServersItem(new Server().url(contextPath))
//                .info(getInfo());
//    }
//
//    @Bean
//    Info getInfo() {
//        return new Info()
//                .title("FNBB Branch Api Service")
//                .description("Description")
//                .version(version)
//                .contact(getContact())
//                .license(new License().name("Apache 2.0").url("https://springdoc.org"));
//    }
//
//    @Bean
//    Contact getContact() {
//        return new Contact()
//                .email("DLFNBBotswanaDev@fnbbotswana.co.bw")
//                .name("FNBB Developers")
//                .url("https://www.fnbbotswana.co.bw/");
//
//    }
//}

package bw.co.fnbbotswana.ws.branchservice.controller.v1;


import bw.co.fnbbotswana.ws.branchservice.controller.model.ErrorResponse;
import bw.co.fnbbotswana.ws.branchservice.exception.BranchException;
import bw.co.fnbbotswana.ws.branchservice.exception.PepV3IntegrationException;
import bw.co.fnbbotswana.ws.branchservice.exception.ServiceException;
import bw.co.fnbbotswana.ws.branchservice.rest.Branch;
import bw.co.fnbbotswana.ws.branchservice.rest.BranchResponse;
import bw.co.fnbbotswana.ws.branchservice.service.BranchInquiryService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import java.io.IOException;
import java.util.List;

@Slf4j
@RestController
@RequiredArgsConstructor
@RequestMapping(value = "/api/v1/", produces = MediaType.APPLICATION_JSON_VALUE)
@Tag(name = "FNBB Branch Service V1", description = "Version 1: Returns a list of FNBB branch names and their codes")
@ApiResponses(value = {
        @ApiResponse(responseCode = "400", description = "Bad request. Please verify your request data", content = {@Content(mediaType = "application/json", schema = @Schema(implementation = ErrorResponse.class))}),
        @ApiResponse(responseCode = "401", description = "You are not authorized to view the resource", content = {@Content(mediaType = "application/json", schema = @Schema(implementation = ErrorResponse.class))}),
        @ApiResponse(responseCode = "403", description = "Accessing the resource you were try to reach is forbidden", content = {@Content(mediaType = "application/json", schema = @Schema(implementation = ErrorResponse.class))}),
        @ApiResponse(responseCode = "500", description = "Server encountered an internal error", content = {@Content(mediaType = "application/json", schema = @Schema(implementation = ErrorResponse.class))}),
})
public class BranchController {

    private static final String CORRELATION_LOGGING = "Correlation-ID set : {}";
    private static final String TIMER_LOGGING = "GET {} - took {} ms";
    private final BranchInquiryService branchInquiryService;

    @Operation(summary = "Inquire for registered company by UIN")
    @PostMapping(value = "branches", produces = MediaType.APPLICATION_JSON_VALUE)
    @ApiResponses(@ApiResponse(responseCode = "200", description = "Successfully receive a list of hard holds", content = {@Content(mediaType = "application/json", schema = @Schema(implementation = Branch.class))}))
    public List<Branch> BranchInquire()
            throws ServiceException, BranchException, PepV3IntegrationException, IOException {

        //final String threadId = CommonUtils.extractThreadIdFromHeader(headers);
        //log.info(CORRELATION_LOGGING, threadId);
        final String currentUriPath = ServletUriComponentsBuilder.fromCurrentRequestUri().build().getPath();
        final long start = System.nanoTime();

       // RequestCorrelation.setId(threadId);

        return branchInquiryService.findAll();
    }
    @PostMapping(value = "b", produces = MediaType.APPLICATION_JSON_VALUE)
    String hello () {
        return "hello";
    }
}

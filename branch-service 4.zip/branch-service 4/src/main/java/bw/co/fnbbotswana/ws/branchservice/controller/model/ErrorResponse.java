package bw.co.fnbbotswana.ws.branchservice.controller.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateTimeSerializer;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.UUID;

@Getter
@Setter
@ToString
@NoArgsConstructor
public class ErrorResponse implements Serializable {

    //@Serial
    private static final long serialVersionUID = 1L;

    @JsonSerialize(using = LocalDateTimeSerializer.class)
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime errorTime;

    private String errorReference;
    private int errorCode;
    private String errorMessage;

    private String source = "FNBB";

    public ErrorResponse(String errorReference, LocalDateTime errorTime, int errorCode, String errorMessage) {
        this.errorReference = errorReference;
        this.errorTime = errorTime;
        this.errorCode = errorCode;
        this.errorMessage = errorMessage;
    }

    public ErrorResponse(int errorCode, String errorMessage) {
        this(UUID.randomUUID().toString(),
                LocalDateTime.now(),
                errorCode,
                errorMessage);
    }
}

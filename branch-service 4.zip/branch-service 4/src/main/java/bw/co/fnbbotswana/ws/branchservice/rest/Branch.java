package bw.co.fnbbotswana.ws.branchservice.rest;

import bw.co.fnbbotswana.ws.branchservice.rest.bootstrap.BranchDeserializer;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import lombok.*;

@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
//@JsonDeserialize(using = BranchDeserializer.class)
public class Branch {

    @JsonProperty(value = "BranchName")
    private String branchName;

    @JsonProperty(value = "BranchCode")
    private String branchCode;

    //location
    @JsonProperty(value = "Location")
    private String location;

    @JsonProperty(value = "PostalAddress")
    private String postalAddress;

    @JsonProperty(value = "Fax")
    private String faxNumber;

    @JsonProperty(value = "Telephone")
    private String telephone;

}

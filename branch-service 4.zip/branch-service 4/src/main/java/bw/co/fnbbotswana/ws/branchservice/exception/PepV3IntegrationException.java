package bw.co.fnbbotswana.ws.branchservice.exception;

public class PepV3IntegrationException extends BaseException {

    public PepV3IntegrationException(int code, String message) {
        super(code, message);
    }

    public PepV3IntegrationException(int code, String message, Throwable cause) {
        super(code, message, cause);
    }

    public PepV3IntegrationException(String message) {
        super(message);
    }

    public PepV3IntegrationException(String message, Throwable cause) {
        super(message, cause);
    }
}

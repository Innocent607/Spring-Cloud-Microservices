package bw.co.fnbbotswana.ws.branchservice.exception;

import lombok.Getter;

@Getter
public class BaseException extends RuntimeException {

    private final int code;
    private final String details;

    public BaseException(int code, String message) {
        super(message);
        this.code = code;
        this.details = message;
    }

    public BaseException(int code, String message,  Throwable cause) {
        super(message, cause);
        this.details = message;
        this.code = code;
    }

    public BaseException(String message) {
        this(99999, message);
    }

    public BaseException(String message, Throwable cause) {
        this(99999, message, cause);
    }
}

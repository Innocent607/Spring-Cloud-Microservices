package bw.co.fnbbotswana.ws.branchservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BranchServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
